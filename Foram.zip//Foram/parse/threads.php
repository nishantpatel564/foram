
<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
  

  <title>welcome to iDiscuss</title>
</head>
<body>

  <?php
  include 'header.php';
  include 'dbconn.php';
  ?>
  <?php
  $id=$_GET['catid'];
  $sql = "SELECT * FROM `idiscuss` WHERE category_id='$id'";
  $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
      $catname=$row['category_name'];
      $catdes=$row['category_description'];
    }
  
  ?>
<div class="container my-3">
  <div class="jumbotron">
  <h1 class="display-4">welcome to <?php    echo $catname;?></h1>
  <p class="lead"><?php echo $catdes?>.</p>
  <hr class="my-4">
  <p>Introduce yourself. The welcome activity will help you get to know your classmates and help create a positive educational environment. ...
Ask questions. ...
Participate. ...
Do not dominate a discussion. ...
Be intellectually rigorous. ...
Be tactful.</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>
  
  
</div>

<?php
$add=false;
$method = $_SERVER['REQUEST_METHOD'];
//echo $method;
if ($method=='POST') {
  $th_tittel=$_POST['tittle'];
  $th_des=$_POST['des'];
  $sno=$_POST['sno'];
  $sql="INSERT INTO `threads` (`threads_tittle`, `threads_des`, `threads_cat_id`, `threads_user_id`, `time`) VALUES ('$th_tittel', '$th_des', '$id', '$sno', CURRENT_TIMESTAMP);";
  $result=mysqli_query($conn,$sql);
  $add=true;
  if ($add) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>success</strong> your question was added please wait for community reply
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
  }
  
}
?>
  
<div class="container my-2">
  <h1 >Ask qustion</h1>
  <?php
  if (isset($_SESSION['loggedin'])&& $_SESSION['loggedin']==true) {
    
      

  echo'
  <form action="'.$_SERVER['REQUEST_URI'].'"method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">qustion tittle</label>
    <input type="text" class="form-control" id="tittle" name="tittle" aria-describedby="emailHelp">
    <small id="emailHelp" class="form-text text-muted">try to ask question simplified way
    </small>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">question description</label>
    <textarea class="form-control" id="des" name="des"rows="3"></textarea>
    <input type="hidden"name="sno"value="'.$_SESSION['id'].'">
    
  </div>
  
  <button type="submit" class="btn btn-success  ">Submit</button>
</form>';}
else {
 echo' <div class="container"style="font-size:30px;"><p>please login to ask question</p></div>';
}
  ?>
</div>
<div class="container">
<h1 >browse qustion</h1>  </div>
  <?php
  $id=$_GET['catid'];
  $sql = "SELECT * FROM `threads` WHERE threads_cat_id='$id'";
  $result = mysqli_query($conn, $sql);
   $noresult=true;
    while ($row = mysqli_fetch_assoc($result)) {
      $noresult=false;
      $id=$row['threads_id'];
      $tittle=$row['threads_tittle'];
      $des=$row['threads_des'];
      $user_id=$row['threads_user_id'];
      $sql2="SELECT user_email FROM `user` WHERE sno='$user_id'";
      $result2=mysqli_query($conn,$sql2);
      $row2=mysqli_fetch_assoc($result2);
     echo'  <div class="media">
  <img src="./img/ujr.png" class="mr-3" alt="..."style="width:50px;">
  <div class="media-body"><p class="text-right mr-3">posted by '.$row2['user_email'].' </p>
    <h5 class="mt-0"><a href="threadsq.php?threads_id='.$id.'">'.$tittle.'</a></h5>
    '.$des.'
  </div>
</div>';
    }
if ($noresult) {
 echo '<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">no qustion found</h1>
    <p class="lead">first person to ask qustion.</p>
  </div>
</div>';
  
}
 //echo var_dump($noresult);

  
  ?>

<?php
  include 'footer.php';
  ?>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
   <script type="text/javascript" charset="utf-8"></script>
         
  </body>
</html>