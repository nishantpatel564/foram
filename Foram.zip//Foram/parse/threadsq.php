
<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <title>welcome to iDiscuss</title>
</head>
<body>

  <?php
  include 'header.php';
  include 'dbconn.php';
  ?>
  <?php
  $id=$_GET['threads_id'];
  $sql = "SELECT * FROM `threads` WHERE threads_id='$id'";
  $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
      $tittle=$row['threads_tittle'];
      $des=$row['threads_des'];
      $threads_user_id=$row['threads_user_id'];
      $sql2="SELECT user_email FROM `user` WHERE sno='$threads_user_id'";
      $result2=mysqli_query($conn,$sql2);
      $row2=mysqli_fetch_assoc($result2);
      $post_by=$row2['user_email'];
      
    }
    
  ?>
<div class="container my-3">
  <div class="jumbotron">
  <h1 class="display-4"> <?php    echo $tittle;?></h1>
  <p class="lead"><?php echo $des;?>.</p>
  <hr class="my-4">
  <p>Introduce yourself. The welcome activity will help you get to know your classmates and help create a positive educational environment. ...
Ask questions. ...
Participate. ...
Do not dominate a discussion. ...
Be intellectually rigorous. ...
Be tactful.</p>
<p class="text-left"style="font-weight:bold;">
<?php echo $post_by;?>
</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>
  
  
</div>
<div class="container my-2">
  <?php
$add=false;
$method = $_SERVER['REQUEST_METHOD'];
//echo $method;
if ($method=='POST') {
  $comment=$_POST['coment'];
  $sno=$_POST['sno'];
  
  $sql="INSERT INTO `comments` ( `coment_cont`, `threads_id`, `coment_time`, `coment_by`) VALUES ( '$comment', '$id', CURRENT_TIME(), '$sno');";
  $result=mysqli_query($conn,$sql);
  $add=true;
  if ($add) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>success</strong> your comment was added 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
  }
  
}
?>
  <h1 >add comment</h1>
  <?php
  if (isset($_SESSION['loggedin'])&& $_SESSION['loggedin']==true) {
  echo'
  <form action="'.$_SERVER['REQUEST_URI'].'"method="POST">

  <div class="form-group">
    <label for="exampleFormControlTextarea1">comment</label>
    <textarea class="form-control" id="coment" name="coment"rows="3"></textarea>
      <input type="hidden"name="sno"value="'.$_SESSION['id'].'">
  </div>
  
  <button type="submit" class="btn btn-success  ">Submit</button>
</form>';}
else {
  echo' <div class="container"style="font-size:30px;"><p>please login to add comments</p></div>';
}
  ?>
</div>

<div class="container">
<h1 >discussion</h1></div>
  <?php
  $id=$_GET['threads_id'];
  $sql = "SELECT * FROM `comments` WHERE threads_id='$id'";
  $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
     $id=$row['threads_tittle'];
      $comment=$row['coment_cont'];
      $user_id=$row['coment_by'];
      $comment_time=$row['coment_time'];
      $sql2="SELECT user_email FROM `user` WHERE sno='$user_id'";
      $result2=mysqli_query($conn,$sql2);
      $row2=mysqli_fetch_assoc($result2);
      
      echo'  <div class="media my-3 mb-2">
        <img src="./img/ujr.png" class="mr-3" alt="..."style="width:50px;">
  <div class="media-body "><h6 class=" mr-3 style="font-weight:bold;">coment by  '.$row2['user_email'].'    '.$comment_time.'</h6>

   '.$comment.'
  </div>
</div>';
    }
  
  ?>
  
  
<?php
  include 'footer.php';
  ?>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>