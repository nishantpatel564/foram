<?php
if ($_SERVER['REQUEST_METHOD']=="POST") {
  include 'dbconn.php';
  $user_email=$_POST['semail'];
  $signuppass=$_POST['password'];
  $cpassword=$_POST['cpassword'];
  $exist=false;
  $existsql="SELECT * FROM `user` WHERE user_email ='$user_email'";
  
  $result=mysqli_query($conn,$existsql);
  $numExistRows=mysqli_num_rows($result);
  if ($numExistRows > 0) {
    $showerror="email already exist";
    echo "<h2>$showerror</h2>";
  }
  else {
    if (($signuppass==$cpassword)) {
      $hash=Password_hash($signuppass,PASSWORD_DEFAULT);
      $sql="INSERT INTO `user` ( `user_email`, `user_password`, `dts`) VALUES ('$user_email', '$hash', CURRENT_TIMESTAMP);";
      $result=mysqli_query($conn, $sql);
      if ($result) {
        $showalert=true;
         header("location:/Foram/index.php?signup=true;");
      }
    }
      else{
        $pass="PASSWORD NOT MATCH";
      echo "<h2>$pass</h2>";
      header("location:/Foram/index.php?passerror=true;");
      }
      
      
    
  }
  
  
  
}


?>