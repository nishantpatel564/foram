<?php
if (isset($_GET['login'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>login </strong>   success 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
  }
  if (isset($_GET['loginerror'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>password </strong> incorrect
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
  }

?>