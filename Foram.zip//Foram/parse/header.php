<?php
session_start();
if (isset($_SESSION['loggedin'])&& $_SESSION['loggedin']==true) {
     $login=true;
      
}
else {
  $login=false;
}?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="/Foram">iDiscuss</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/Foram">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Foram/parse/about.php">About</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <?php
        include 'dbconn.php';
        $sql="SELECT * FROM `idiscuss` LIMIT 3"; //WHERE 1 ";
        $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
       echo' <a class="dropdown-item" href="./parse/threads.php?catid='.$row['category_id'].'">'.$row['category_name'].'</a>
          ';}
          ?>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Foram/parse/contact.php">Contect us</a>
      </li>
    </ul>
    <form class="form-inline my-1 my-lg-0"method="get"action="/Foram/parse/sarch.php?sarch='nishant'">
      <input class="form-control mr-sm-2" type="search" name="sarch"placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-1 my-sm-0" type="submit">Search</button>
        
    <?php  echo '';?>
      <?php
      if ($login) {
        echo' 
       <p class="text-light my-3 ml-2"> '.$_SESSION['user_email'].'</p>
        <a class="btn btn-outline-success my-9 my-sm-0 text-white bg-success ml-2" href="/Foram/parse/logout.php">Logout</a>';
      }
      ?>

<?php
if (!$login) {
  
echo'
 <button class="btn btn-outline-success my-9 my-sm-0 text-white bg-success ml-2" type="button"data-toggle="modal" data-target="#loginModal">Login</button>
        
            <button class="btn btn-outline-success my-2 my-sm-0 ml-2 bg-success text-white" type="button" data-toggle="modal" data-target="#signupModal">Signup</button>';}?>
    </form>
  </div>
</nav>
<?php
include 'loginModal.php';
include 'signupModal.php';
include 'alart.php';
include 'alart2.php';
?>
